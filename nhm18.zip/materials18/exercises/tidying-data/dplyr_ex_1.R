# Load the NYC flights dataset
# This should take ~5 minutes
library(tidyverse)
library(nycflights13)

# Q1: Select year, month, arr_delay and dep_delay from the `flights` dataset


# Q2: create a new data frame called h3 that contains only variable that end with
# "time" without typing every single variable name


# Q3: select everything but distance and hour


# Q4: select year, month, day and then hour, minute =, tume_hour using minimal typing.

