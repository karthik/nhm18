library(nycflights13)
library(tidyverse)

# Print out a summary with variables min_dist and max_dist


