# Load the library janitor

library(janitor)
bad_data <- readxl::read_excel("data/dirty_data.xlsx")
bad_data

# Can you brainstorm what are things wrong with this dataset in terms of data tidyness?
# tip, use View to look at the full dataset. Also use glimpse to look around more.
# What do you see? 3 minutes.



# Now that we've discussed this, write some piped code to clean at least 4 issues.

# What other diagnostics can we do on the data? 2 minutes


# tabulating these data

