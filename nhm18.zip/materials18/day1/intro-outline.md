# Introduction to the course

## What we will cover

1. Health and safety
    - fire exits
    - swipe cards and tailgating
    - pest management
    - hours allowed onsite

2. Timetable (general)
    - coffee/lunch
    - teaching times
    - evening plans

3. Timetable (specific)
    - brief run through
    - plan for Friday

4. Teaching
    - how do we teach?
    - where are the materials?
    - how can you get the most out of this week?
    - what to do if you're stuck/struggling
    - what to do if you're finding it easy

5. Reproducibility introduction
   - this is essentially the aim of the course
   - brief example of a basic workflow for us to come back to 
